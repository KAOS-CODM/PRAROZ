const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");
menuBtn.addEventListener("click",() =>{
    sidebar.classList.toggle("open");
    menuBtn.classList.toggle("active");
});

function openPopup(){
    document.getElementById("popupForm").style.display = "block";
}

function closePopup(){
    document.getElementById("popupForm").style.display = "none";
}

setTimeout(openPopup, 5000);

document.getElementById("popupForm").addEventListener("submit", function (event) {
    event.preventDefault();

    let form = event.target;
    let action = form.action;

    if (!(form instanceof HTMLFormElement)) {
        return;
    }

    let formData = new FormData(form);
    
    // Get reCAPTCHA response
    let recaptchaResponse = grecaptcha.getResponse();
    console.log("reCAPTCHA Response:", recaptchaResponse);

    // Check if reCAPTCHA is completed
    if (!recaptchaResponse) {
        alert("Please complete the reCAPTCHA verification.");
        return;
    }

    window.onload = function(){
        grecaptcha.render("g-recaptcha");
    };

    // Append reCAPTCHA response to form data
    formData.append("g-recaptcha-response", recaptchaResponse);

    fetch(action, {
        method: "POST",
        body: formData,
        headers: {
            "Accept": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.ok) {
            document.getElementById("response-message").innerText = "Thank you for subscribing!";
            form.reset();
            grecaptcha.reset(); // Reset reCAPTCHA after submission

            setTimeout(() =>{
                document.getElementById("popupForm").style.display = this.nonce;
            },2000);
        } else {
            alert("Error submitting form. Please try again.");
        }
    })
    .catch(error => console.error("Formspree Error:", error));
});
